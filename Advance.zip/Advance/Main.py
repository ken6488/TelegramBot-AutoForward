from telethon.sync import TelegramClient
from telethon.errors.rpcerrorlist import PhoneNumberBannedError
import pickle, os
from colorama import init, Fore
from time import sleep

init()

n = Fore.RESET
lg = "\033[1;34m"
r = "\033[1;31m"
w =  "\033[1;37m"
cy =  "\033[1;36m"
ye = Fore.YELLOW
gr = "\033[1;32m"
m = Fore.MAGENTA
IT = "\033[3m"
BL = "\033[1m"
LW = "\033[1;37m"
DG = "\033[1;30m"

colors = [LW]

try:
    import requests
except ImportError:
    print(f'{IT}[i] Installing module - requests...{n}')
    os.system('pip install requests')

def banner():
    import random
    # fancy logo
    b = [
    

'╔═══╦═══╦╗──╔╦═══╦═╗─╔╦═══╦═══╗',
'║╔═╗╠╗╔╗║╚╗╔╝║╔═╗║║╚╗║║╔═╗║╔══╝',
'║║─║║║║║╠╗║║╔╣║─║║╔╗╚╝║║─╚╣╚══╗',
'║╚═╝║║║║║║╚╝║║╚═╝║║╚╗║║║─╔╣╔══╝',
'║╔═╗╠╝╚╝║╚╗╔╝║╔═╗║║─║║║╚═╝║╚══╗',
'╚╝─╚╩═══╝─╚╝─╚╝─╚╩╝─╚═╩═══╩═══╝',

    ]
    for char in b:
        print(f'{random.choice(colors)}{char}{n}')
    #print('=============SON OF GOD==============')
    print(f'{DG}{IT}Version: {DG}1.0{n} |{DG} Author: {DG}@SOMOYADDER\n')
    print(cy+'-YOUR KEY IS SUCCESSFULLY ACTIVATED  BY @SOMOYADDER-')
  
def clr():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')

while True:
    clr()
    banner()
    print(cy+' +--------------------AVDANCE--------------------+'+n)
    print(r+'ACCOUNTS MANAGEMENT:'+n)
    print(IT+'╚═════════><01> ACCOUNTS LOGIN'+n)
    print(n+'           <02> FILTER ALL BANNDED ACCOUNTS'+n)
    print(n+'           <03> DELETE SPECIFIC ACCOUNT'+n)
    print(n+'           <04> DISPLAY ALL ACCOUNTS'+n)
    print(r+'ADVANCED ADDER OPTION:'+n)
    print(r+'╚═════════><05> DIRECT ADDER'+n)
    print(r+'           <06> HIDDEN MEMBER ADDER (NEW)'+n)
    print(r+'           <07> PRIVATE HIDDEN MEMBER  ADDER (NEW)'+n)
    print(r+'           <08> ADDING MEMBER FROM CONTACT'+n)
    print(r+'ADVANCED TOOLS:'+n)
    print(lg+'╚═════════><09> AUTO CORRECT ADDER'+n)
    print(lg+'           <10> AUTO CORRECT DELETE'+n)
    print(lg+'           <11> POST VIEW INCREASER'+n)
    print(lg+'           <12> Report Scam'+n)
    print(r+'EDIT ACCOUNTS:'+n)
    print(m+'╚═════════><13> CHANGE FIRST NAME'+n)
    print(m+'           <14> CHANGE LAST NAME'+n)
    print(m+'           <15> SET PROFILE PIC'+n)
    print(m+'           <16> SET BIO'+n)
    print(m+'           <17> SET USER NAME'+n)
    print(m+'           <18> SET 2 STEP VERIFICATION'+n)
    print(m+'           <19> REMOVE 2 STEP VERIFICATION'+n)
    print(r+'JOIN & LEAVE:'+n)
    print(gr+'╚═════════><20> JOIN GROUP & CHANNEL'+n)
    print(gr+'           <21> LEAVE GROUP & CHANNEL'+n)
    print(gr+'           <22> JOIN PRIVATE GROUP & CHANNEL'+n)
    print(gr+'           <23> LEAVE PRIVATE GROUP & CHANNEL'+n)
    print(r+'MY CONTACT INFORMATION:'+n)
    print(cy+'╚═════════><24> Subscribe My YouTube Channel'+n)
    print(cy+'           <25> Join My Telegram Channel'+n)
    print(cy+'           <26> Join My Telegram Group'+n)
    print(cy+'           <27> My Telegram Id'+n)
    print(r+'SHUTDOWN:'+n)
    print(lg+'╚═════════><28> EXIT'+n)
    print(lg+'           <29> EXIT & CLEAR'+n)
    
    a = int(input(f'\nEnter Your Choice: {DG}'))
    
    if a == 1:
        new_accs = []
        with open('vars.txt', 'ab') as g:
            number_to_add = int(input(f'\n{gr} [~] {cy}Enter number of accounts to add: {DG}'))
            for i in range(number_to_add):
                phone_number = str(input(f'\n{gr} [~] {cy}Enter Phone Number: {DG}'))
                parsed_number = ''.join(phone_number.split())
                pickle.dump([parsed_number], g)
                new_accs.append(parsed_number)
            print(f'\n{gr} [i]{cy} Saved all accounts in vars.txt')
            clr()
            print(f'\n{cy} [*] Logging in from new accounts\n')
            for number in new_accs:
                c = TelegramClient(f'sessions/{number}', 8088717 , '7d1e0295ee1c2628f1933e9ffd2d8b78')
                c.start(number)
                print(f'{gr}[+] 𝐋𝐨𝐠𝐢𝐧 𝐬𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮L')
                c.disconnect()
            input(f'\n Press enter to goto main menu...')

        g.close() 
    elif a == 2:
        accounts = []
        banned_accs = []
        h = open('vars.txt', 'rb')
        while True:
            try:
                accounts.append(pickle.load(h))
            except EOFError:
                break
        h.close()
        if len(accounts) == 0:
            print(r+'[!] There are no accounts! Please add some and retry')
            sleep(3)
        else:
            for account in accounts:
                phone = str(account[0])
                client = TelegramClient(f'sessions/{phone}', 8088717 , '7d1e0295ee1c2628f1933e9ffd2d8b78')
                client.connect()
                if not client.is_user_authorized():
                    try:
                        client.send_code_request(phone)
                        #client.sign_in(phone, input('[+] Enter the code: '))
                        print(f'{gr}[+] {phone} is not banned{n}')
                    except PhoneNumberBannedError:
                        print(r+str(phone) + ' is banned!'+n)
                        banned_accs.append(account)
            if len(banned_accs) == 0:
                print(gr+'Congrats! No banned accounts')
                input('\nPress enter to goto main menu...')
            else:
                for m in banned_accs:
                    accounts.remove(m)
                with open('vars.txt', 'wb') as k:
                    for a in accounts:
                        Phone = a[0]
                        pickle.dump([Phone], k)
                k.close()
                print(cy+'[i] All banned accounts removed'+n)
                input('\nPress enter to goto main menu...')
    elif a == 3:
        accs = []
        f = open('vars.txt', 'rb')
        while True:
            try:
                accs.append(pickle.load(f))
            except EOFError:
                break
        f.close()
        i = 0
        print(f'{gr}[i] Choose an account to delete\n')
        for acc in accs:
            print(f'{cy}[{i}] {acc[0]}{DG}')
            i += 1
        index = int(input(f'\n{cy}[+] Enter a choice: {DG}'))
        phone = str(accs[index][0])
        session_file = phone + '.session'
        if os.name == 'nt':
            os.system(f'del sessions\\{session_file}')
        else:
            os.system(f'rm sessions/{session_file}')
        del accs[index]
        f = open('vars.txt', 'wb')
        for account in accs:
            pickle.dump(account, f)
        print(f'\n{gr}[+] Account Deleted{n}')
        input(f'\nPress enter to goto main menu...')
        f.close()   
    elif a == 4:
        accs = []
        f = open('vars.txt', 'rb')
        while True:
            try:
                accs.append(pickle.load(f))
            except EOFError:
                break
        f.close()
        print(f'\n{gr}')
        print(f'\tList Of Phone Numbers Are')
        print(f'====================================================')
        i = 0
        for z in accs:
            print(f'\t {cy} {z[0]}')
            i += 1
        print(f'{gr}====================================================')
        input('\nPress enter to goto main menu....')
        
        
    elif a == 5:
        clr()
        banner()
        os.system('python Adder.py')
        exit ()
    elif a == 6:
        clr()
        banner()
        os.system('python Adder.py')
        exit ()
    elif a == 7:
        clr()
        banner()
        os.system('python Adder.py')
        exit ()
    elif a == 8:
        clr()
        banner()
        os.system('python Adder.py')
        exit ()
        
    elif a == 12:
        accounts = []
        f = open('vars.txt', 'rb')
        while True:
            try:
                accounts.append(pickle.load(f))
            except EOFError:
                break

        
        #print('\n' + info + cy + ' Checking for banned accounts...' + cy)
        print(f'{cy} Checking for banned accounts...' )
        for a in accounts:
            phn = a[0]
            print(f'Checking {cy}{phn}')
            clnt = TelegramClient(f'sessions/{phn}', 8027196 , '9b70b20efd67e9b99edc395d78407cfa')
            clnt.connect()
            banned = []
            if not clnt.is_user_authorized():
                try:
                    clnt.send_code_request(phn)
                    print('ck')
                except PhoneNumberBannedError:
                    print(f'{error} {w}{phn} {r}is banned!{cy}')
                    banned.append(a)
            for z in banned:
                accounts.remove(z)
                print('{cy}Banned account removed[Remove permanently using main.py]{cy}')
            clnt.disconnect()
        print(' Sessions created!')
        clr()
        banner()
        accounts = []
        f = open('vars.txt', 'rb')
        while True:
            try:
                accounts.append(pickle.load(f))
            except EOFError:
                break
        print(f'{cy} Total accounts: {DG}{len(accounts)}')
        number_of_accs = int(input(f'{cy} Enter number of accounts to Report: {DG}'))
        choice = str(input(f'{cy} Send Message For Report {DG}'))
        to_use = [x for x in accounts[:number_of_accs]]
        for l in to_use: accounts.remove(l)
        with open('vars.txt', 'wb') as f:
            for a in accounts:
                pickle.dump(a, f)
            for ab in to_use:
                pickle.dump(ab, f)
            f.close()
        sleep_time = 1
        print(f'{cy} -- Sending Reports from {DG}{len(to_use)}{cy} account(s) --')   
        send_status = 0
        
        approx_members_count = 0
        index = 0
        for acc in to_use:
            stop = index + 60
            c = TelegramClient(f'sessions/{acc[0]}', 3910389 , '86f861352f0ab76a251866059a6adbd6')
            print(f'User: {cy}{acc[0]}{cy} -- {cy}Starting session... ')
            c.start(acc[0])
            acc_name = c.get_me().first_name
            try:
                c.send_message(scam,choice)
                print(f'Report Done From: {cy}{acc_name}{gr}  To Notoscam-- ')
                send_status += 1
            except Exception as e:
                print(f'{e}')
                continue
        if send_status != 0:
            print(f"\n{gr}session ended")
            input(f'\n{cy} Press enter to exit...')
        else:
            print(f"\n{gr}All reports done sucesfully")
            input(f'\n{cy} Press enter to exit...')
    elif a == 24:
    	os.system("termux-open-url https://www.youtube.com/@SOMOY_ADDER")
    elif a == 25:
    	os.system("termux-open-url https://t.me/SOMOYADDERC")
    elif a == 26:
    	os.system("termux-open-url https://t.me/SOMOYADDERG")
    elif a == 27:
    	os.system("termux-open-url https://t.me/SOMOYADDER")
    elif a == 28:
        exit()
    elif a == 29:    
        clr()
        banner()
        exit()
        
   
      